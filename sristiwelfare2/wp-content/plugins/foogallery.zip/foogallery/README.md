![Plugin Banner](https://s3.amazonaws.com/foogallery/foogallery-large.png)

Why choose FooGallery? Stunning gallery layouts, responsive, retina-ready, lightning fast, easy to use.

[FooGallery Homepage](http://foo.gallery/)

[FooGallery Demos](http://foo.gallery/demos)

[FooGallery on wordpress.org](https://wordpress.org/plugins/foogallery/)

[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/fooplugins/foogallery/badges/quality-score.png?b=develop)](https://scrutinizer-ci.com/g/fooplugins/foogallery/?branch=develop)
