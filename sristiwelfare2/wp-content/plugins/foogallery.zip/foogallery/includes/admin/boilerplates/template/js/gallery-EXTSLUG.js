//FooGallery {name} template script
//Add any javascript that will be needed by your gallery template. This will be output to the frontend
