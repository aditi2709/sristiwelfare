=== Contact Form Widget - Contact Query, Form Maker ===
Contributors: awordpresslife
Tags: Contact form widget, Query form builder, Customer feedback table, support Query, form plugin
Donate link: http://awplife.com/
Requires at least: 3.8
Tested up to: 5.2.3
Stable tag: 1.0.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create simple powerful contact forms easily and free.
Site Contact, Query Form, Contact Us, Report Form. 

== Description ==

= Contact Form Widget - Form Builder =

Now your users can get in touch with you because contact for provide you a good functionality of storing you support query and you can check that queries from backend on the All query page.

Contact Form plugin is an ultimate WordPress Plugin with great features and designed to create simple powerful query form easily and free.

Contact Plugin is a form builder plugin for WordPress blog or website, use widget and shortcode to display the contact form on the website and it is based on irresistible CSS & JS, So it is very amazing, responsive and easy to use.

With this plugin you can stay in touch with your visitors very easily. It's also easy-to-use with a great and user friendly backend (option panel). To create a contact form you just need to use the shortcode.

This form builder plugin provide you many customization options that you want. You can change the field labels and you can see the query in a responsive table, you can also see on your mobile because it’s fully responsive.

The contact form has a all query page, there is a well designed table so you can easily check every contact query.

This plugin is batter then contact form 7 because contact form seven send query on your email but in this plugin, all queries are stored in table so you could check and follow up later if required. 

* It is very important to use good quality and good design Form plugin.

* Need a simple configured and best functioning form, then do not hesitate to choose this Form Plugin.

* Form is what you are looking for, as it is simple to install and configurable via a simple configuration page.

https://www.youtube.com/watch?v=hWjQ3NOmfTs

**Upgrade To Premium Plugin - <a href="https://awplife.com/wordpress-plugins/contact-form-premium/">Click Here</a>**

**Check Premium Plugin Demo - <a href="https://awplife.com/demo/contact-form-premium-admin-demo/">Click Here</a>**

== QUERY TABLE FUNCTION ==

This plugin has a query table functinality, it stores all query that you will get as feedback query.

> #### **Demo for Lite and Pro Version**

> * [Contact Form Premium](https://awplife.com/demo/contact-form-premium/ "Contact Form Premium")
> * [Form With Logo](https://awplife.com/demo/contact-form-premium/contact-form-logo/ "With Logo")
> * [Form Without Logo](https://awplife.com/demo/contact-form-premium/contact-form-without-logo/ "Without Logo")
> * [Logo Size](https://awplife.com/demo/contact-form-premium/contact-form-logo-size/ "Logo Size")
> * [Form Tittle Size](https://awplife.com/demo/contact-form-premium/contact-form-tittle-size/ "Tittle Size")
> * [Title Color](https://awplife.com/demo/contact-form-premium/contact-form-title-color/ "Title Color")
> * [Label Icon Color](https://awplife.com/demo/contact-form-premium/label-icon-color/ "Label Icon Color")
> * [Place Holder Color](https://awplife.com/demo/contact-form-premium/place-holder-color/ "Place Holder Color")
> * [Background Color](https://awplife.com/demo/contact-form-premium/background-color/ "Background Color")
> * [Contact Form Widget](https://awplife.com/demo/contact-form-premium/contact-form-widget/ "Widget")
> * [Admin Demo](https://awplife.com/demo/contact-form-premium-admin-demo/ "Admin Demo")


== WHAT CAN YOU DO WITH FORMS PLUGIN ==

* Plugin allows you to create many different forms and send the results to your site.

* Use the shortcode consists of a single line, you can insert a form to any page or post.

* Unlike other Form  plugins, our Forms never asks any profile registration.

* Let’s see the examples of some form types that you may build.

The dynamic web form allows you to view and manage all form submissions. The form plugin stores submissions in your database for future reference.

There are two methods into the plugin to add the contact form on WordPress blog site. You can add it as a widget or in a page.

== PROVIDES WITH FULLY RESPONSIVE DESIGN ==

Responsiveness is a most Important feature of this plugin. It looks  good on any size of devices included mobiles, tablets and others.

== WIDGETS AND SHORTCODES ==

Using widgets and Shortcode easy insert your form in a page/post or integrate as widget.

== Screenshots ==

1. Shortcode Example 1
2. Shortcode Example 2
3. Shortcode Example 3
4. Shortcode Example 4
5. Shortcode Example 5
6. Shortcode Example 6
7. Shortcode Example 7
8. Shortcode Example 8
9. Widget Example 1
10. Widget Example 2
11. Widget Example 3
12. Widget Example 4
13. Widget Example 5
14. Widget Example 6
15. Widget Example 7
16. Widget Example 8
17. Admin Dashboard For Query Management
18. Form Settings

== Installation ==

Install Contact Form Widget either via the WordPress.org plugin directory or by uploading the files to your server.

After activating Contact Form Widget plugin, go to plugin menu.

Login into admin dashboard. Go to Appearance --> Widgets : Contact Form Widget

Activate the Plugin into widget area for theme.

Configure settings and save.

That's it. You're ready to go!


== Frequently Asked Questions ==

Have any queries?

Please post your question on plugin support forum

https://wordpress.org/support/plugin/new-contact-form-widget/

== Changelog ==

= 1.0.9 =

* Tested for WordPress 5.2.3

= 1.0.8 =

* Tested for WordPress 5.2.2

= 1.0.7 =

* Bug Fixed & Tested for WordPress 5.2.2

== Upgrade Notice ==
This is an initial release. Start with version 0.0.1 and share your feedback <a href="https://wordpress.org/support/view/plugin-reviews/new-contact-form-widget//">here</a>.