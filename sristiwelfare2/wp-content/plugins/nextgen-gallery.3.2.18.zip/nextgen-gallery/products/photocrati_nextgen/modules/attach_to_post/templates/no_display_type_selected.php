<p class="<?php echo esc_attr($css_class) ?>">
	<?php esc_html_e($no_display_type_selected)?>
</p>