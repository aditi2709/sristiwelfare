<?php

return array(
	'tempfolder2024' => 'tempfolder2024',
);